from django.apps import AppConfig


class ChartitappConfig(AppConfig):
    name = 'chartitApp'
