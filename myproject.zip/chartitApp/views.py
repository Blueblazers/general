from django.http import HttpResponse
from django.http import JsonResponse
from django.shortcuts import render
from textblob import TextBlob
import matplotlib.pyplot as plt
import numpy as np
import tweepy

def index(request):
    name = ''
    p = 0
    n = 0
    e = 0
    c = 0
    if request.method == "POST":
        name = request.POST['firstname']
        #print(name)
        try:
            consumer_key = 'JDtCkMyUhtlORGDjzpesNuDeG'
            consumer_secret = 'QJ3384LZTbfYuCIR4xLAtG2OpbFafCf9fim23AW5mnDkOhvhY1'
            access_token = '2589282229-bzccTVYF1kTqEH4AXNTPTQh2x4dZLTJ8A8svMxh'
            access_token_secret = '08QnDLMVYrsFhp29OJyPp8jY1FOOomUftFRiZVsV0CxDw'
            auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
            auth.set_access_token(access_token, access_token_secret)
            api = tweepy.API(auth)
            public_tweets = tweepy.Cursor(api.search, q = name).items(200)
            print(public_tweets)
            #public_tweets = api.search(name)
            for tweet in public_tweets:
                analysis = TextBlob(tweet.text)
                if analysis.sentiment.polarity > 0:
                    #if analysis.sentiment.subjectivity > 0.6:
                    p += 1
                elif analysis.sentiment.polarity < 0:
                    #if analysis.sentiment.subjectivity > 0.6:
                    n += 1
                else:
                    #if analysis.sentiment.subjectivity > 0.6:
                    e += 1
                c += 1


                print(analysis.sentiment.polarity)
                print(analysis.sentiment.subjectivity)
                print("\n")
            #print("C:", c)

            cal = {
                'text': [p, n, e]
            }
            return render(request, 'index.html', cal)
            # plt.show()

        except:
            disty = {
                'greet': "Warning! No Data Entered"
            }
            return render(request, 'index.html', disty)
            print("No Data")
    cal = {
        'text': [p, n, e]
    }
    return render(request, 'index.html', cal)
